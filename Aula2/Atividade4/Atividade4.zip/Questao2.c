#include <stdio.h>

int comprar_itens () {
    int itens= 10;
    return itens; 
}
    
    int main() {
    printf("Exercicio 2:\n");
    
    printf("O cliente comprou %d itens aleatorios", comprar_itens());
   
  

    return 0;
}